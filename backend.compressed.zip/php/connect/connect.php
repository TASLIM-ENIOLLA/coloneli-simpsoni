<?php

    $connect = new mysqli(
        "localhost",
        "id19227110_colson_ecommerce_admin",
        "_Aderibigbe1904",
        "id19227110_colson_ecommerce"
    ) or die("Could't connect to database");

?>
